//------------------------------------------------------------------------------
// <copyright file="Resource.h" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
//------------------------------------------------------------------------------

//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ColorBasics.rc
//
#define IDI_APP                         100
#define IDD_APP                         100
#define IDC_VIDEOVIEW                   1000
#define IDC_STATUS                      1001
#define IDC_BUTTON_SCREENSHOT           1002
// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
